-- Stok Yönetim Sistemi - Veritabanı Şeması
-- MySQL 5.7+ / MariaDB 10.2+

CREATE DATABASE IF NOT EXISTS stok_yonetim
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_turkish_ci;

USE stok_yonetim;

-- Admin kullanıcılar tablosu
CREATE TABLE IF NOT EXISTS kullanicilar (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_adi VARCHAR(50) NOT NULL UNIQUE,
  sifre_hash VARCHAR(255) NOT NULL,
  ad_soyad VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Ürünler tablosu
CREATE TABLE IF NOT EXISTS urunler (
  id INT AUTO_INCREMENT PRIMARY KEY,
  urun_kodu VARCHAR(50) NOT NULL UNIQUE,
  urun_adi VARCHAR(255) NOT NULL,
  kategori VARCHAR(100) NOT NULL,
  renk VARCHAR(50) DEFAULT NULL,
  beden VARCHAR(20) DEFAULT NULL,
  stok_adedi INT NOT NULL DEFAULT 0,
  alis_fiyati DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  satis_fiyati DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  aciklama TEXT DEFAULT NULL,
  kapak_gorseli VARCHAR(255) DEFAULT NULL,
  aktif_pasif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_kategori (kategori),
  INDEX idx_aktif (aktif_pasif),
  INDEX idx_stok (stok_adedi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;
