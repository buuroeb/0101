-- Stok Yönetim Sistemi - Örnek Veriler
-- Varsayılan admin: admin / admin123

USE stok_yonetim;

-- Admin kullanıcı (şifre: admin123, bcrypt hash)
-- Hash aşağıda seed script ile oluşturulacak, bu placeholder'dır
-- Gerçek hash server tarafında seed.js ile oluşturulur

INSERT IGNORE INTO kullanicilar (kullanici_adi, sifre_hash, ad_soyad)
VALUES ('admin', '$2b$10$placeholder', 'Sistem Yöneticisi');

-- Örnek ürünler
INSERT INTO urunler (urun_kodu, urun_adi, kategori, renk, beden, stok_adedi, alis_fiyati, satis_fiyati, aciklama, aktif_pasif) VALUES
('ELB-001', 'Keten Yazlık Elbise', 'Elbise', 'Beyaz', 'M', 12, 250.00, 499.90, 'Yazlık keten kumaş, rahat kalıp', 1),
('ELB-002', 'Saten Gece Elbisesi', 'Elbise', 'Siyah', 'S', 3, 400.00, 899.90, 'Özel gece davetleri için saten elbise', 1),
('ELB-003', 'Çiçek Desenli Midi Elbise', 'Elbise', 'Pembe', 'L', 0, 180.00, 359.90, 'Günlük kullanım için çiçek desenli', 1),
('GMK-001', 'Oversize Beyaz Gömlek', 'Gömlek', 'Beyaz', 'M', 25, 120.00, 249.90, 'Pamuklu oversize kesim gömlek', 1),
('GMK-002', 'Çizgili Keten Gömlek', 'Gömlek', 'Mavi', 'L', 2, 150.00, 299.90, 'Keten kumaş, çizgili desen', 1),
('PNT-001', 'Yüksek Bel Palazzo Pantolon', 'Pantolon', 'Siyah', 'M', 8, 200.00, 449.90, 'Yüksek bel, geniş paça palazzo', 1),
('PNT-002', 'Slim Fit Kumaş Pantolon', 'Pantolon', 'Lacivert', 'S', 1, 180.00, 399.90, 'Ofis için slim fit kumaş pantolon', 1),
('CKT-001', 'Blazer Ceket', 'Ceket', 'Krem', 'M', 6, 350.00, 749.90, 'Tek düğme blazer ceket', 1),
('CKT-002', 'Deri Biker Ceket', 'Ceket', 'Siyah', 'S', 0, 500.00, 1199.90, 'Suni deri biker ceket', 0),
('ETK-001', 'Pileli Midi Etek', 'Etek', 'Bordo', 'M', 15, 130.00, 279.90, 'Pileli midi boy etek', 1),
('TRK-001', 'Triko Kazak', 'Triko', 'Gri', 'L', 4, 160.00, 349.90, 'Yün karışımlı triko kazak', 1),
('AKS-001', 'İpek Fular', 'Aksesuar', 'Karışık', NULL, 20, 80.00, 179.90, '%100 ipek fular', 1),
('AKS-002', 'Deri Kemer', 'Aksesuar', 'Kahverengi', NULL, 10, 60.00, 139.90, 'Hakiki deri kemer', 1);
