-- QR Satış Modülü - İşlem Geçmişi Tablosu
-- Mevcut veritabanına ekleyin

USE stok_yonetim;

CREATE TABLE IF NOT EXISTS satis_islemleri (
  id INT AUTO_INCREMENT PRIMARY KEY,
  urun_id INT NOT NULL,
  urun_kodu VARCHAR(50) NOT NULL,
  urun_adi VARCHAR(255) NOT NULL,
  islem_tipi ENUM('satis', 'iade') NOT NULL DEFAULT 'satis',
  adet INT NOT NULL,
  birim_fiyat DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  toplam_tutar DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  onceki_stok INT NOT NULL,
  yeni_stok INT NOT NULL,
  admin_id INT NOT NULL,
  admin_kullanici_adi VARCHAR(50) NOT NULL,
  aciklama TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_urun_id (urun_id),
  INDEX idx_urun_kodu (urun_kodu),
  INDEX idx_islem_tipi (islem_tipi),
  INDEX idx_admin_id (admin_id),
  INDEX idx_created_at (created_at),
  FOREIGN KEY (urun_id) REFERENCES urunler(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES kullanicilar(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;
