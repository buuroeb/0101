function requireAuth(req, res, next) {
  if (!req.session.user) {
    req.session.error = 'Lütfen giriş yapın.';
    return res.redirect('/login');
  }
  next();
}

module.exports = { requireAuth };
