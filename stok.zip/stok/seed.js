/**
 * Seed Script - Veritabanı ve admin kullanıcısını oluşturur
 * Kullanım: npm run seed
 */

require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');

async function seed() {
  // Connect without database to create it
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    multipleStatements: true,
    charset: 'utf8mb4',
  });

  console.log('Veritabanı oluşturuluyor...');

  // Run schema
  const schema = fs.readFileSync(path.join(__dirname, 'sql', 'schema.sql'), 'utf8');
  await conn.query(schema);

  // Switch to database
  await conn.changeUser({ database: process.env.DB_NAME });

  // Create admin user with hashed password
  const password = 'admin123';
  const hash = await bcrypt.hash(password, 10);

  await conn.execute(
    `INSERT INTO kullanicilar (kullanici_adi, sifre_hash, ad_soyad)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE sifre_hash = VALUES(sifre_hash)`,
    ['admin', hash, 'Sistem Yöneticisi']
  );

  console.log('Admin kullanıcı oluşturuldu: admin / admin123');

  // Insert sample products
  const [existing] = await conn.execute('SELECT COUNT(*) AS cnt FROM urunler');
  if (existing[0].cnt === 0) {
    const seedSql = fs.readFileSync(path.join(__dirname, 'sql', 'seed.sql'), 'utf8');
    // Remove the placeholder admin insert and USE statement
    const productInserts = seedSql
      .split('\n')
      .filter(line => line.startsWith('INSERT INTO urunler'))
      .join('\n');

    if (productInserts) {
      await conn.query(productInserts);
      console.log('Örnek ürünler eklendi.');
    }
  } else {
    console.log('Ürünler zaten mevcut, atlandı.');
  }

  // Ensure uploads directory exists
  const uploadsDir = path.join(__dirname, 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
    console.log('Uploads klasörü oluşturuldu.');
  }

  await conn.end();
  console.log('\nKurulum tamamlandı!');
  console.log('Sunucuyu başlatın: npm start');
  console.log('Adres: http://localhost:' + (process.env.PORT || 3000));
}

seed().catch((err) => {
  if (err.code === 'ECONNREFUSED') {
    console.error('HATA: MySQL sunucusuna baglanamadi!');
    console.error('XAMPP Control Panel\'den MySQL servisini baslatin.');
  } else {
    console.error('Seed hatasi:', err.code, '-', err.message);
  }
  process.exit(1);
});
