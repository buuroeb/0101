// ===== QR Sales Scanner =====
(function () {
  'use strict';

  // DOM elements
  const btnStartCamera = document.getElementById('btnStartCamera');
  const btnStopCamera = document.getElementById('btnStopCamera');
  const qrReaderEl = document.getElementById('qr-reader');
  const qrPlaceholder = document.getElementById('qr-reader-placeholder');
  const manualInput = document.getElementById('manualCode');
  const btnManualLookup = document.getElementById('btnManualLookup');
  const statusEl = document.getElementById('qr-status');
  const productCard = document.getElementById('product-card');
  const productEmpty = document.getElementById('product-empty');
  const productNotFound = document.getElementById('product-not-found');
  const notFoundMsg = document.getElementById('not-found-msg');
  const saleQtyInput = document.getElementById('saleQty');
  const btnQtyPlus = document.getElementById('btnQtyPlus');
  const btnQtyMinus = document.getElementById('btnQtyMinus');
  const btnCompleteSale = document.getElementById('btnCompleteSale');
  const saleNoteInput = document.getElementById('saleNote');
  const saleTotalEl = document.getElementById('sale-total');
  const saleSuccessCard = document.getElementById('sale-success-card');
  const saleSuccessMsg = document.getElementById('sale-success-msg');
  const saleNewStock = document.getElementById('sale-new-stock');
  const btnNewSale = document.getElementById('btnNewSale');

  let html5QrCode = null;
  let currentProduct = null;
  let isProcessing = false;

  // ——— Camera Scanner ———
  btnStartCamera.addEventListener('click', startCamera);
  btnStopCamera.addEventListener('click', stopCamera);

  async function startCamera() {
    if (typeof Html5Qrcode === 'undefined') {
      showStatus('QR kütüphanesi yüklenemedi. Sayfayı yenileyin.', 'error');
      return;
    }

    btnStartCamera.style.display = 'none';
    btnStopCamera.style.display = '';
    qrPlaceholder.style.display = 'none';
    qrReaderEl.style.display = 'block';

    html5QrCode = new Html5Qrcode('qr-reader');

    try {
      await html5QrCode.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        onScanSuccess,
        () => {}
      );
    } catch (err) {
      console.error('Camera error:', err);
      showStatus('Kamera açılamadı. Tarayıcı kamera izni verildiğinden emin olun.', 'error');
      resetCameraUI();
    }
  }

  async function stopCamera() {
    if (html5QrCode) {
      try { await html5QrCode.stop(); } catch (e) { /* already stopped */ }
      html5QrCode.clear();
      html5QrCode = null;
    }
    resetCameraUI();
  }

  function resetCameraUI() {
    btnStartCamera.style.display = '';
    btnStopCamera.style.display = 'none';
    qrReaderEl.style.display = 'none';
    qrPlaceholder.style.display = '';
  }

  function onScanSuccess(decodedText) {
    if (isProcessing) return;
    const code = extractProductCode(decodedText);
    if (code) {
      manualInput.value = code;
      lookupProduct(code);
    }
  }

  // ——— Manual Lookup ———
  btnManualLookup.addEventListener('click', () => {
    const code = manualInput.value.trim();
    if (code) lookupProduct(code);
  });

  manualInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const code = manualInput.value.trim();
      if (code) lookupProduct(code);
    }
  });

  // ——— Product Lookup ———
  async function lookupProduct(code) {
    if (isProcessing) return;
    isProcessing = true;

    hideAllCards();
    showStatus('Ürün aranıyor...', 'info');

    try {
      const res = await fetch('/admin/sales/lookup?kod=' + encodeURIComponent(code));
      const data = await res.json();

      if (data.success && data.product) {
        currentProduct = data.product;
        renderProduct(data.product);
        hideStatus();
      } else {
        currentProduct = null;
        notFoundMsg.textContent = data.error || 'Ürün bulunamadı.';
        productNotFound.style.display = '';
        showStatus('"' + code + '" kodlu ürün bulunamadı.', 'error');
      }
    } catch (err) {
      console.error('Lookup error:', err);
      showStatus('Bağlantı hatası. Lütfen tekrar deneyin.', 'error');
      productEmpty.style.display = '';
    } finally {
      isProcessing = false;
    }
  }

  // ——— Render Product Card ———
  function renderProduct(p) {
    document.getElementById('product-name').textContent = p.urun_adi;
    document.getElementById('product-code').textContent = p.urun_kodu;
    document.getElementById('product-category').textContent = p.kategori;

    const colorEl = document.getElementById('product-color');
    if (p.renk) { colorEl.textContent = p.renk; colorEl.style.display = ''; }
    else { colorEl.style.display = 'none'; }

    const sizeEl = document.getElementById('product-size');
    if (p.beden) { sizeEl.textContent = p.beden; sizeEl.style.display = ''; }
    else { sizeEl.style.display = 'none'; }

    document.getElementById('product-price').textContent = formatMoney(p.satis_fiyati);
    updateStockDisplay(p.stok_adedi);

    const statusSpan = document.getElementById('product-status');
    if (p.aktif_pasif) {
      statusSpan.innerHTML = '<span class="badge badge-success">Aktif</span>';
    } else {
      statusSpan.innerHTML = '<span class="badge badge-danger">Pasif</span>';
    }

    // Image
    const imgArea = document.getElementById('product-image-area');
    if (p.kapak_gorseli) {
      imgArea.innerHTML = '<img src="/uploads/' + encodeURIComponent(p.kapak_gorseli) + '" alt="" class="qr-product-img" />';
    } else {
      imgArea.innerHTML = '<div class="thumb-placeholder thumb-lg"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></div>';
    }

    saleQtyInput.value = 1;
    saleNoteInput.value = '';
    updateSaleTotal();
    productCard.style.display = '';
  }

  function updateStockDisplay(stock) {
    const el = document.getElementById('product-stock');
    el.textContent = stock + ' adet';
    el.className = 'qr-detail-value qr-stock-value';
    if (stock === 0) el.classList.add('stock-zero');
    else if (stock <= 3) el.classList.add('stock-low');
    else el.classList.add('stock-ok');
  }

  // ——— Sale Total Calculation ———
  function updateSaleTotal() {
    if (!currentProduct) return;
    const qty = parseInt(saleQtyInput.value, 10) || 0;
    const total = qty * parseFloat(currentProduct.satis_fiyati);
    saleTotalEl.textContent = formatMoney(total);
  }

  saleQtyInput.addEventListener('input', updateSaleTotal);

  // ——— Quantity Controls ———
  btnQtyPlus.addEventListener('click', () => {
    const v = parseInt(saleQtyInput.value, 10) || 0;
    if (currentProduct && v >= currentProduct.stok_adedi) {
      showStatus('Stok miktarını aşamazsınız.', 'error');
      return;
    }
    saleQtyInput.value = Math.min(v + 1, 9999);
    updateSaleTotal();
  });

  btnQtyMinus.addEventListener('click', () => {
    const v = parseInt(saleQtyInput.value, 10) || 0;
    saleQtyInput.value = Math.max(v - 1, 1);
    updateSaleTotal();
  });

  // ——— Complete Sale ———
  btnCompleteSale.addEventListener('click', completeSale);

  async function completeSale() {
    if (!currentProduct || isProcessing) return;

    const adet = parseInt(saleQtyInput.value, 10);
    if (isNaN(adet) || adet <= 0) {
      showStatus('Geçerli bir adet girin.', 'error');
      return;
    }

    if (adet > currentProduct.stok_adedi) {
      showStatus(`Yetersiz stok. Mevcut: ${currentProduct.stok_adedi}, İstenen: ${adet}`, 'error');
      return;
    }

    isProcessing = true;
    btnCompleteSale.disabled = true;

    try {
      const res = await fetch('/admin/sales/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          urun_kodu: currentProduct.urun_kodu,
          adet: adet,
          aciklama: saleNoteInput.value.trim() || null,
        }),
      });

      const data = await res.json();

      if (data.success) {
        // Show success card
        productCard.style.display = 'none';
        saleSuccessMsg.textContent = data.message;
        saleNewStock.textContent = data.stok_adedi + ' adet';
        saleSuccessCard.style.display = '';
        showStatus(data.message, 'success');

        currentProduct.stok_adedi = data.stok_adedi;
      } else {
        showStatus(data.error || 'Satış başarısız.', 'error');
      }
    } catch (err) {
      console.error('Sale error:', err);
      showStatus('Bağlantı hatası.', 'error');
    } finally {
      btnCompleteSale.disabled = false;
      isProcessing = false;
    }
  }

  // ——— New Sale Button ———
  btnNewSale.addEventListener('click', () => {
    hideAllCards();
    productEmpty.style.display = '';
    manualInput.value = '';
    manualInput.focus();
    currentProduct = null;
    hideStatus();
  });

  // ——— Helpers ———
  function extractProductCode(text) {
    if (!text) return null;
    const trimmed = text.trim();

    try {
      const obj = JSON.parse(trimmed);
      if (obj.urun_kodu) return obj.urun_kodu;
      if (obj.code) return obj.code;
      if (obj.productCode) return obj.productCode;
    } catch (e) { /* not JSON */ }

    try {
      const url = new URL(trimmed);
      const code = url.searchParams.get('kod') || url.searchParams.get('code');
      if (code) return code;
    } catch (e) { /* not a URL */ }

    return trimmed;
  }

  function formatMoney(val) {
    return parseFloat(val).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' });
  }

  function showStatus(msg, type) {
    statusEl.textContent = msg;
    statusEl.className = 'qr-status qr-status-' + type;
    statusEl.style.display = '';
    if (type === 'success') {
      setTimeout(hideStatus, 4000);
    }
  }

  function hideStatus() {
    statusEl.style.display = 'none';
  }

  function hideAllCards() {
    productCard.style.display = 'none';
    productEmpty.style.display = 'none';
    productNotFound.style.display = 'none';
    saleSuccessCard.style.display = 'none';
  }
})();
