// ===== Mobile Sidebar Toggle =====
(function () {
  const toggle = document.getElementById('sidebarToggle');
  const close = document.getElementById('sidebarClose');
  const overlay = document.getElementById('sidebarOverlay');

  function openSidebar() { document.body.classList.add('sidebar-open'); }
  function closeSidebar() { document.body.classList.remove('sidebar-open'); }

  if (toggle) toggle.addEventListener('click', openSidebar);
  if (close) close.addEventListener('click', closeSidebar);
  if (overlay) overlay.addEventListener('click', closeSidebar);
})();

// ===== Stock Adjustment Buttons =====
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('.btn-stock');
  if (!btn) return;

  const control = btn.closest('.stock-control');
  const id = control.dataset.id;
  const action = parseInt(btn.dataset.action, 10);

  try {
    const res = await fetch(`/admin/products/${id}/stock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ miktar: action }),
    });

    const data = await res.json();

    if (data.success) {
      const valueEl = control.querySelector('.stock-value');
      valueEl.textContent = data.stok_adedi;

      // Flash effect
      valueEl.style.background = action > 0 ? '#dcfce7' : '#fef2f2';
      setTimeout(() => { valueEl.style.background = ''; }, 400);

      // Update row highlight
      const row = control.closest('tr');
      row.classList.remove('row-warning', 'row-danger');
      if (data.stok_adedi === 0) row.classList.add('row-danger');
      else if (data.stok_adedi <= 3) row.classList.add('row-warning');
    } else {
      alert(data.error || 'Stok güncellenemedi.');
    }
  } catch {
    alert('Bağlantı hatası.');
  }
});

// ===== Auto-dismiss Alerts =====
document.querySelectorAll('.alert').forEach((el) => {
  setTimeout(() => {
    el.style.transition = 'opacity 0.3s, transform 0.3s';
    el.style.opacity = '0';
    el.style.transform = 'translateY(-8px)';
    setTimeout(() => el.remove(), 300);
  }, 4000);
});

// ===== Image Preview on File Select =====
(function () {
  const fileInput = document.getElementById('kapak_gorseli');
  const preview = document.getElementById('image-preview');
  if (!fileInput || !preview) return;

  fileInput.addEventListener('change', function () {
    preview.innerHTML = '';
    const file = this.files[0];
    if (!file || !file.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.style.cssText = 'width:80px;height:80px;object-fit:cover;border-radius:10px;border:1px solid var(--gray-200);margin-top:12px;';
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
})();
