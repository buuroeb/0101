const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const salesController = require('../controllers/salesController');

router.use(requireAuth);

// QR Sales page
router.get('/scan', salesController.salesPage);

// AJAX: product lookup by code
router.get('/lookup', salesController.lookup);

// AJAX: complete sale
router.post('/complete', salesController.completeSale);

// Sales history page
router.get('/history', salesController.historyPage);

// AJAX: reporting data
router.get('/report', salesController.report);

module.exports = router;
