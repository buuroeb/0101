const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const stockController = require('../controllers/stockController');

router.use(requireAuth);

// QR scan page
router.get('/scan', stockController.scanPage);

// AJAX: product lookup by code
router.get('/lookup', stockController.lookup);

// AJAX: stock update
router.post('/update', stockController.update);

module.exports = router;
