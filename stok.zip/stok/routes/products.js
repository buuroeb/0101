const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const productController = require('../controllers/productController');

// All /admin routes require authentication
router.use(requireAuth);

router.get('/dashboard', productController.dashboard);

router.get('/products', productController.list);
router.get('/products/new', productController.createForm);
router.post('/products/new', upload.single('kapak_gorseli'), productController.create);
router.get('/products/:id/edit', productController.editForm);
router.post('/products/:id/edit', upload.single('kapak_gorseli'), productController.update);
router.post('/products/:id/delete', productController.delete);
router.post('/products/:id/stock', productController.adjustStock);

module.exports = router;
