# Butik Stok Yönetim Sistemi

Hafif, modüler bir butik mağaza stok/envanter yönetim paneli.

## Gereksinimler

- Node.js 18+
- MySQL 5.7+ veya MariaDB 10.2+

## Kurulum

```bash
# 1. Bağımlılıkları yükleyin
npm install

# 2. .env dosyasını düzenleyin (gerekirse)
#    Varsayılan: root kullanıcı, şifresiz, localhost

# 3. MySQL'in çalıştığından emin olun (XAMPP Control Panel)

# 4. Veritabanını ve örnek verileri oluşturun
npm run seed

# 5. Sunucuyu başlatın
npm start
```

Tarayıcıda açın: **http://localhost:3000**

## Giriş Bilgileri

| Alan | Değer |
|------|-------|
| Kullanıcı Adı | `admin` |
| Şifre | `admin123` |

## Proje Yapısı

```
stok/
├── server.js              # Express giriş noktası
├── seed.js                # Veritabanı kurulum scripti
├── config/
│   └── db.js              # MySQL bağlantı havuzu
├── middleware/
│   ├── auth.js            # Oturum kontrolü
│   └── upload.js          # Multer görsel yükleme
├── controllers/
│   ├── authController.js  # Giriş/çıkış işlemleri
│   └── productController.js # Ürün CRUD + stok
├── routes/
│   ├── auth.js            # /login, /logout
│   └── products.js        # /admin/* rotaları
├── views/
│   ├── partials/          # Header, footer
│   ├── login.ejs
│   ├── dashboard.ejs
│   ├── products.ejs
│   └── product-form.ejs
├── public/
│   ├── css/style.css
│   ├── js/app.js
│   └── uploads/           # Ürün görselleri
└── sql/
    ├── schema.sql         # Tablo tanımları
    └── seed.sql           # Örnek veriler
```

## Özellikler

- Admin giriş sistemi (bcrypt + session)
- Dashboard (özet metrikler, düşük stok uyarıları)
- Ürün CRUD (ekle, düzenle, sil, listele)
- Arama ve kategori filtresi
- Tek tıkla stok artır/azalt (AJAX)
- Görsel yükleme (JPG, PNG, WebP)
- Aktif/pasif ürün durumu
- Düşük stok uyarısı (≤ 3 adet)
- Responsive tasarım
- Türkçe arayüz

## Gelecek Geliştirmeler

- Barkod okuyucu entegrasyonu
- POS (satış noktası) modülü
- Sipariş yönetimi
- E-ticaret entegrasyonu
- Raporlama ve grafikler
- Çoklu kullanıcı ve rol yönetimi
