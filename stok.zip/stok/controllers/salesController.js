const db = require('../config/db');

// QR Sales page
exports.salesPage = (req, res) => {
  res.render('qr-sales', { title: 'QR Satış' });
};

// Lookup product by urun_kodu (AJAX) — reuses same logic as stock lookup
exports.lookup = async (req, res) => {
  try {
    const { kod } = req.query;
    if (!kod || !kod.trim()) {
      return res.status(400).json({ error: 'Ürün kodu gerekli.' });
    }

    const [rows] = await db.execute(
      `SELECT id, urun_kodu, urun_adi, kategori, renk, beden,
              stok_adedi, alis_fiyati, satis_fiyati, aciklama,
              kapak_gorseli, aktif_pasif
       FROM urunler WHERE urun_kodu = ?`,
      [kod.trim()]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Ürün bulunamadı.' });
    }

    res.json({ success: true, product: rows[0] });
  } catch (err) {
    console.error('Sales lookup error:', err);
    res.status(500).json({ error: 'Sunucu hatası.' });
  }
};

// Complete sale — transaction-safe stock reduction
exports.completeSale = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { urun_kodu, adet, aciklama } = req.body;

    if (!urun_kodu || !urun_kodu.trim()) {
      return res.status(400).json({ error: 'Ürün kodu gerekli.' });
    }

    const quantity = parseInt(adet, 10);
    if (isNaN(quantity) || quantity <= 0) {
      return res.status(400).json({ error: 'Adet pozitif bir sayı olmalıdır.' });
    }

    await conn.beginTransaction();

    // Lock the row for update to prevent race conditions
    const [rows] = await conn.execute(
      'SELECT id, urun_kodu, urun_adi, stok_adedi, satis_fiyati FROM urunler WHERE urun_kodu = ? FOR UPDATE',
      [urun_kodu.trim()]
    );

    if (rows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ error: 'Ürün bulunamadı.' });
    }

    const product = rows[0];
    const oncekiStok = product.stok_adedi;
    const yeniStok = oncekiStok - quantity;

    if (yeniStok < 0) {
      await conn.rollback();
      return res.status(400).json({
        error: `Yetersiz stok. Mevcut: ${oncekiStok}, Satılmak istenen: ${quantity}`,
      });
    }

    // Update stock
    await conn.execute(
      'UPDATE urunler SET stok_adedi = ? WHERE id = ?',
      [yeniStok, product.id]
    );

    const user = req.session.user;
    const toplamTutar = (parseFloat(product.satis_fiyati) * quantity).toFixed(2);

    // Insert transaction log
    await conn.execute(
      `INSERT INTO satis_islemleri
        (urun_id, urun_kodu, urun_adi, islem_tipi, adet, birim_fiyat, toplam_tutar,
         onceki_stok, yeni_stok, admin_id, admin_kullanici_adi, aciklama)
       VALUES (?, ?, ?, 'satis', ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        product.id, product.urun_kodu, product.urun_adi,
        quantity, product.satis_fiyati, toplamTutar,
        oncekiStok, yeniStok,
        user.id, user.kullanici_adi,
        aciklama ? aciklama.trim() : null,
      ]
    );

    await conn.commit();

    res.json({
      success: true,
      stok_adedi: yeniStok,
      toplam_tutar: toplamTutar,
      message: `${quantity} adet "${product.urun_adi}" satışı tamamlandı. Toplam: ${parseFloat(toplamTutar).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}`,
    });
  } catch (err) {
    await conn.rollback();
    console.error('Complete sale error:', err);
    res.status(500).json({ error: 'Satış işlemi sırasında hata oluştu.' });
  } finally {
    conn.release();
  }
};

// Sales history page
exports.historyPage = async (req, res) => {
  try {
    const { arama, tarih_bas, tarih_bit } = req.query;
    let sql = 'SELECT * FROM satis_islemleri WHERE 1=1';
    const params = [];

    if (arama) {
      sql += ' AND (urun_adi LIKE ? OR urun_kodu LIKE ? OR admin_kullanici_adi LIKE ?)';
      const term = `%${arama}%`;
      params.push(term, term, term);
    }

    if (tarih_bas) {
      sql += ' AND DATE(created_at) >= ?';
      params.push(tarih_bas);
    }

    if (tarih_bit) {
      sql += ' AND DATE(created_at) <= ?';
      params.push(tarih_bit);
    }

    sql += ' ORDER BY created_at DESC LIMIT 200';

    const [transactions] = await db.execute(sql, params);

    // Summary stats
    const [summaryRows] = await db.execute(
      `SELECT
        COUNT(*) AS toplam_islem,
        COALESCE(SUM(adet), 0) AS toplam_adet,
        COALESCE(SUM(toplam_tutar), 0) AS toplam_ciro
       FROM satis_islemleri
       WHERE islem_tipi = 'satis'
         AND DATE(created_at) = CURDATE()`
    );

    res.render('sales-history', {
      title: 'Satış Geçmişi',
      transactions,
      summary: summaryRows[0],
      filters: {
        arama: arama || '',
        tarih_bas: tarih_bas || '',
        tarih_bit: tarih_bit || '',
      },
    });
  } catch (err) {
    console.error('Sales history error:', err);
    req.session.error = 'Satış geçmişi yüklenirken hata oluştu.';
    res.redirect('/admin/dashboard');
  }
};

// Reporting API (AJAX)
exports.report = async (req, res) => {
  try {
    // Top selling products (last 30 days)
    const [topSelling] = await db.execute(
      `SELECT urun_kodu, urun_adi,
              SUM(adet) AS toplam_satis,
              SUM(toplam_tutar) AS toplam_ciro
       FROM satis_islemleri
       WHERE islem_tipi = 'satis'
         AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY urun_kodu, urun_adi
       ORDER BY toplam_satis DESC
       LIMIT 10`
    );

    // Unsold products (no sales in last 30 days)
    const [unsold] = await db.execute(
      `SELECT u.urun_kodu, u.urun_adi, u.stok_adedi, u.kategori
       FROM urunler u
       LEFT JOIN satis_islemleri s
         ON u.id = s.urun_id
         AND s.islem_tipi = 'satis'
         AND s.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       WHERE s.id IS NULL
         AND u.aktif_pasif = 1
       ORDER BY u.stok_adedi DESC
       LIMIT 20`
    );

    // Daily sales summary (last 7 days)
    const [dailySales] = await db.execute(
      `SELECT DATE(created_at) AS tarih,
              COUNT(*) AS islem_sayisi,
              SUM(adet) AS toplam_adet,
              SUM(toplam_tutar) AS toplam_ciro
       FROM satis_islemleri
       WHERE islem_tipi = 'satis'
         AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
       GROUP BY DATE(created_at)
       ORDER BY tarih DESC`
    );

    res.json({
      success: true,
      topSelling,
      unsold,
      dailySales,
    });
  } catch (err) {
    console.error('Sales report error:', err);
    res.status(500).json({ error: 'Rapor yüklenirken hata oluştu.' });
  }
};
