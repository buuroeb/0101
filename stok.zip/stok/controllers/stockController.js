const db = require('../config/db');

// QR Scan page
exports.scanPage = (req, res) => {
  res.render('qr-scan', { title: 'QR Stok' });
};

// Lookup product by urun_kodu (AJAX)
exports.lookup = async (req, res) => {
  try {
    const { kod } = req.query;
    if (!kod || !kod.trim()) {
      return res.status(400).json({ error: 'Ürün kodu gerekli.' });
    }

    const [rows] = await db.execute(
      `SELECT id, urun_kodu, urun_adi, kategori, renk, beden,
              stok_adedi, alis_fiyati, satis_fiyati, aciklama,
              kapak_gorseli, aktif_pasif
       FROM urunler WHERE urun_kodu = ?`,
      [kod.trim()]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Ürün bulunamadı.' });
    }

    res.json({ success: true, product: rows[0] });
  } catch (err) {
    console.error('Stock lookup error:', err);
    res.status(500).json({ error: 'Sunucu hatası.' });
  }
};

// Update stock by urun_kodu (AJAX)
exports.update = async (req, res) => {
  try {
    const { urun_kodu, miktar, islem } = req.body;

    if (!urun_kodu || !urun_kodu.trim()) {
      return res.status(400).json({ error: 'Ürün kodu gerekli.' });
    }

    const amount = parseInt(miktar, 10);
    if (isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: 'Miktar pozitif bir sayı olmalıdır.' });
    }

    if (!['ekle', 'azalt'].includes(islem)) {
      return res.status(400).json({ error: 'Geçersiz işlem türü.' });
    }

    const [rows] = await db.execute(
      'SELECT id, stok_adedi FROM urunler WHERE urun_kodu = ?',
      [urun_kodu.trim()]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Ürün bulunamadı.' });
    }

    const product = rows[0];
    const delta = islem === 'ekle' ? amount : -amount;
    const newStock = product.stok_adedi + delta;

    if (newStock < 0) {
      return res.status(400).json({
        error: `Yetersiz stok. Mevcut: ${product.stok_adedi}, Çıkarılmak istenen: ${amount}`,
      });
    }

    await db.execute(
      'UPDATE urunler SET stok_adedi = ? WHERE id = ?',
      [newStock, product.id]
    );

    res.json({
      success: true,
      stok_adedi: newStock,
      message: islem === 'ekle'
        ? `${amount} adet stok eklendi.`
        : `${amount} adet stok düşüldü.`,
    });
  } catch (err) {
    console.error('Stock update error:', err);
    res.status(500).json({ error: 'Stok güncellenirken hata oluştu.' });
  }
};
