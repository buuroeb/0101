const db = require('../config/db');
const fs = require('fs');
const path = require('path');

const LOW_STOCK_THRESHOLD = 3;

// Dashboard
exports.dashboard = async (req, res) => {
  try {
    const [[totals]] = await db.execute(
      `SELECT
        COUNT(*) AS toplam,
        SUM(aktif_pasif = 1) AS aktif,
        SUM(stok_adedi = 0) AS stok_bitti,
        SUM(stok_adedi > 0 AND stok_adedi <= ?) AS dusuk_stok
      FROM urunler`,
      [LOW_STOCK_THRESHOLD]
    );

    const [recent] = await db.execute(
      'SELECT id, urun_kodu, urun_adi, kategori, stok_adedi, satis_fiyati, created_at FROM urunler ORDER BY created_at DESC LIMIT 5'
    );

    const [lowStock] = await db.execute(
      'SELECT id, urun_kodu, urun_adi, stok_adedi FROM urunler WHERE stok_adedi <= ? AND stok_adedi > 0 AND aktif_pasif = 1 ORDER BY stok_adedi ASC',
      [LOW_STOCK_THRESHOLD]
    );

    res.render('dashboard', {
      title: 'Dashboard',
      totals,
      recent,
      lowStock,
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    req.session.error = 'Dashboard yüklenirken hata oluştu.';
    res.redirect('/admin/dashboard');
  }
};

// List products
exports.list = async (req, res) => {
  try {
    const { arama, kategori } = req.query;
    let sql = 'SELECT * FROM urunler WHERE 1=1';
    const params = [];

    if (arama) {
      sql += ' AND (urun_adi LIKE ? OR urun_kodu LIKE ?)';
      const term = `%${arama}%`;
      params.push(term, term);
    }

    if (kategori) {
      sql += ' AND kategori = ?';
      params.push(kategori);
    }

    sql += ' ORDER BY created_at DESC';

    const [products] = await db.execute(sql, params);
    const [categories] = await db.execute('SELECT DISTINCT kategori FROM urunler ORDER BY kategori');

    res.render('products', {
      title: 'Ürünler',
      products,
      categories: categories.map((c) => c.kategori),
      filters: { arama: arama || '', kategori: kategori || '' },
      LOW_STOCK_THRESHOLD,
    });
  } catch (err) {
    console.error('List error:', err);
    req.session.error = 'Ürünler yüklenirken hata oluştu.';
    res.redirect('/admin/dashboard');
  }
};

// New product form
exports.createForm = async (req, res) => {
  const [categories] = await db.execute('SELECT DISTINCT kategori FROM urunler ORDER BY kategori');
  res.render('product-form', {
    title: 'Yeni Ürün',
    product: null,
    categories: categories.map((c) => c.kategori),
  });
};

// Create product
exports.create = async (req, res) => {
  try {
    const data = validateProduct(req.body);
    if (data.error) {
      req.session.error = data.error;
      return res.redirect('/admin/products/new');
    }

    const kapak_gorseli = req.file ? req.file.filename : null;

    await db.execute(
      `INSERT INTO urunler (urun_kodu, urun_adi, kategori, renk, beden, stok_adedi, alis_fiyati, satis_fiyati, aciklama, kapak_gorseli, aktif_pasif)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.urun_kodu, data.urun_adi, data.kategori, data.renk, data.beden,
        data.stok_adedi, data.alis_fiyati, data.satis_fiyati, data.aciklama,
        kapak_gorseli, data.aktif_pasif,
      ]
    );

    req.session.success = 'Ürün başarıyla eklendi.';
    res.redirect('/admin/products');
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      req.session.error = 'Bu ürün kodu zaten mevcut.';
      return res.redirect('/admin/products/new');
    }
    console.error('Create error:', err);
    req.session.error = 'Ürün eklenirken hata oluştu.';
    res.redirect('/admin/products/new');
  }
};

// Edit product form
exports.editForm = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM urunler WHERE id = ?', [req.params.id]);
    if (rows.length === 0) {
      req.session.error = 'Ürün bulunamadı.';
      return res.redirect('/admin/products');
    }
    const [categories] = await db.execute('SELECT DISTINCT kategori FROM urunler ORDER BY kategori');
    res.render('product-form', {
      title: 'Ürün Düzenle',
      product: rows[0],
      categories: categories.map((c) => c.kategori),
    });
  } catch (err) {
    console.error('Edit form error:', err);
    req.session.error = 'Ürün yüklenirken hata oluştu.';
    res.redirect('/admin/products');
  }
};

// Update product
exports.update = async (req, res) => {
  const id = req.params.id;
  try {
    const data = validateProduct(req.body);
    if (data.error) {
      req.session.error = data.error;
      return res.redirect(`/admin/products/${id}/edit`);
    }

    let kapak_gorseli_sql = '';
    const params = [
      data.urun_kodu, data.urun_adi, data.kategori, data.renk, data.beden,
      data.stok_adedi, data.alis_fiyati, data.satis_fiyati, data.aciklama,
      data.aktif_pasif,
    ];

    if (req.file) {
      kapak_gorseli_sql = ', kapak_gorseli = ?';
      params.push(req.file.filename);

      // Eski görseli sil
      const [old] = await db.execute('SELECT kapak_gorseli FROM urunler WHERE id = ?', [id]);
      if (old[0]?.kapak_gorseli) {
        const oldPath = path.join(__dirname, '..', 'public', 'uploads', old[0].kapak_gorseli);
        fs.unlink(oldPath, () => {});
      }
    }

    params.push(id);

    await db.execute(
      `UPDATE urunler SET
        urun_kodu = ?, urun_adi = ?, kategori = ?, renk = ?, beden = ?,
        stok_adedi = ?, alis_fiyati = ?, satis_fiyati = ?, aciklama = ?,
        aktif_pasif = ?${kapak_gorseli_sql}
      WHERE id = ?`,
      params
    );

    req.session.success = 'Ürün başarıyla güncellendi.';
    res.redirect('/admin/products');
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      req.session.error = 'Bu ürün kodu zaten mevcut.';
      return res.redirect(`/admin/products/${id}/edit`);
    }
    console.error('Update error:', err);
    req.session.error = 'Ürün güncellenirken hata oluştu.';
    res.redirect(`/admin/products/${id}/edit`);
  }
};

// Delete product
exports.delete = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT kapak_gorseli FROM urunler WHERE id = ?', [req.params.id]);
    if (rows[0]?.kapak_gorseli) {
      const imgPath = path.join(__dirname, '..', 'public', 'uploads', rows[0].kapak_gorseli);
      fs.unlink(imgPath, () => {});
    }
    await db.execute('DELETE FROM urunler WHERE id = ?', [req.params.id]);
    req.session.success = 'Ürün silindi.';
  } catch (err) {
    console.error('Delete error:', err);
    req.session.error = 'Ürün silinirken hata oluştu.';
  }
  res.redirect('/admin/products');
};

// Stock adjustment (AJAX)
exports.adjustStock = async (req, res) => {
  try {
    const { id } = req.params;
    const { miktar } = req.body;
    const amount = parseInt(miktar, 10);

    if (isNaN(amount)) {
      return res.status(400).json({ error: 'Geçersiz miktar.' });
    }

    const [rows] = await db.execute('SELECT stok_adedi FROM urunler WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Ürün bulunamadı.' });
    }

    const newStock = rows[0].stok_adedi + amount;
    if (newStock < 0) {
      return res.status(400).json({ error: 'Stok negatif olamaz.' });
    }

    await db.execute('UPDATE urunler SET stok_adedi = ? WHERE id = ?', [newStock, id]);
    res.json({ success: true, stok_adedi: newStock });
  } catch (err) {
    console.error('Stock adjust error:', err);
    res.status(500).json({ error: 'Stok güncellenirken hata oluştu.' });
  }
};

// Validation helper
function validateProduct(body) {
  const {
    urun_kodu, urun_adi, kategori, renk, beden,
    stok_adedi, alis_fiyati, satis_fiyati, aciklama, aktif_pasif,
  } = body;

  if (!urun_kodu || !urun_kodu.trim()) return { error: 'Ürün kodu zorunludur.' };
  if (!urun_adi || !urun_adi.trim()) return { error: 'Ürün adı zorunludur.' };
  if (!kategori || !kategori.trim()) return { error: 'Kategori zorunludur.' };

  const stok = parseInt(stok_adedi, 10);
  if (isNaN(stok) || stok < 0) return { error: 'Stok adedi geçerli bir sayı olmalıdır.' };

  const alis = parseFloat(alis_fiyati);
  if (isNaN(alis) || alis < 0) return { error: 'Alış fiyatı geçerli olmalıdır.' };

  const satis = parseFloat(satis_fiyati);
  if (isNaN(satis) || satis < 0) return { error: 'Satış fiyatı geçerli olmalıdır.' };

  return {
    urun_kodu: urun_kodu.trim(),
    urun_adi: urun_adi.trim(),
    kategori: kategori.trim(),
    renk: renk ? renk.trim() : null,
    beden: beden ? beden.trim() : null,
    stok_adedi: stok,
    alis_fiyati: alis,
    satis_fiyati: satis,
    aciklama: aciklama ? aciklama.trim() : null,
    aktif_pasif: aktif_pasif === '1' || aktif_pasif === 'on' ? 1 : 0,
  };
}
