const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.loginPage = (req, res) => {
  if (req.session.user) return res.redirect('/admin/dashboard');
  res.render('login', { title: 'Giriş Yap' });
};

exports.login = async (req, res) => {
  try {
    const { kullanici_adi, sifre } = req.body;

    if (!kullanici_adi || !sifre) {
      req.session.error = 'Kullanıcı adı ve şifre gereklidir.';
      return res.redirect('/login');
    }

    const [rows] = await db.execute(
      'SELECT * FROM kullanicilar WHERE kullanici_adi = ?',
      [kullanici_adi]
    );

    if (rows.length === 0) {
      req.session.error = 'Geçersiz kullanıcı adı veya şifre.';
      return res.redirect('/login');
    }

    const user = rows[0];
    const match = await bcrypt.compare(sifre, user.sifre_hash);

    if (!match) {
      req.session.error = 'Geçersiz kullanıcı adı veya şifre.';
      return res.redirect('/login');
    }

    req.session.regenerate((err) => {
      if (err) {
        req.session.error = 'Oturum hatası.';
        return res.redirect('/login');
      }
      req.session.user = {
        id: user.id,
        kullanici_adi: user.kullanici_adi,
        ad_soyad: user.ad_soyad,
      };
      res.redirect('/admin/dashboard');
    });
  } catch (err) {
    console.error('Login error:', err);
    req.session.error = 'Sunucu hatası.';
    res.redirect('/login');
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
};
